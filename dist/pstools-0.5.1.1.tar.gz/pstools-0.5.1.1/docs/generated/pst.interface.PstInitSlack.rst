pst.interface.PstInitSlack
==========================

.. automodule:: pst.interface.PstInitSlack

   
   
   .. rubric:: Functions

   .. autosummary::
   
      conf
      cpar
      escape
      main
      parse_dict
      parse_slack_output
      url
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      handle_command
   
   

   
   
   