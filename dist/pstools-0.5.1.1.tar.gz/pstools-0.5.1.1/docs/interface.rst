.. pst.interface:

.. currentmodule:: pst.interface


:mod:`interface`
=========================

Gui
--------------------
.. autosummary::
   :toctree: generated/

   PstInitGui

Slack
--------------------
.. autosummary::
   :toctree: generated/

   PstInitSlack
