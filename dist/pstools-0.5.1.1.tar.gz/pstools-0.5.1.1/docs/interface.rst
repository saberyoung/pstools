.. pst.interface:

.. currentmodule:: pst.interface


:mod:`interface` -- interface tools
====================================

Gui
--------------------
.. autosummary::
   :toctree: generated/

   PstInitGui

Slack
--------------------
.. autosummary::
   :toctree: generated/

   PstInitSlack
