.. pst.view:

.. currentmodule:: pst.view


:mod:`view` -- tools for visulazation
======================================

make figure
--------------------
.. autosummary::
   :toctree: generated/

   PstPlotter
