import os
os.system('git add .')
os.system('git commit -m 0.4')
os.system('git push -f origin master')
