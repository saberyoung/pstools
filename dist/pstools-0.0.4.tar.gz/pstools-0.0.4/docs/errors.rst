Probable errors
=================

``ImportError: /lib64/libstdc++.so.6``
---------------------------------------

- reason: the Gcc dynamic library version is too old.

- how to solve::
  #edit bash
  LD_LIBRARY_PATH=/home/feng/anaconda3/lib:$LD_LIBRARY_PATH
  export LD_LIBRARY_PATH
