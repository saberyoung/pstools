pst.pipeline.PstGetTilings
============================

.. currentmodule:: pst.pipeline.PstGetTilings

.. autoclass:: PstGetTilings
   :members:
