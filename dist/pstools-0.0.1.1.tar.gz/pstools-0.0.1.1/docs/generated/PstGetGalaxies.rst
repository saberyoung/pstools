pst.pipeline.PstGetGalaxies
=============================

.. currentmodule:: pst.pipeline.PstGetGalaxies

.. autoclass:: PstGetGalaxies
   :members:
