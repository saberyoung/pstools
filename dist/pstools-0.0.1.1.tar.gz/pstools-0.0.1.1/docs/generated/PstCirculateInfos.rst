pst.pipeline.PstCirculateInfos
================================

.. currentmodule:: pst.circulate.PstCirculateInfos

.. autoclass:: PstCirculateInfos
   :members:
