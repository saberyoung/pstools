# PSTools: Pointing Scheduler in responce to Triggers

**tutorial**
https://pstools-documentation.readthedocs.io/en/latest/

structure
=============

pipeline
--
* tilings
* galaxies

view
--
* plot
