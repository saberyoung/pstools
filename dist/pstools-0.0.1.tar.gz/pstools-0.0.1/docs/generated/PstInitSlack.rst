pst.pipeline.PstInitSlack
============================

.. currentmodule:: pst.interface.PstInitSlack

.. autoclass:: PstInitSlack
   :members:
