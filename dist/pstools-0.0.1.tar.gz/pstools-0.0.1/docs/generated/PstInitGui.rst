pst.pipeline.PstInitGui
=========================

.. currentmodule:: pst.interface.PstInitGui

.. autoclass:: PstInitGui
   :members:
