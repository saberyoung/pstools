pst.pipeline.PstPlotter
=========================

.. currentmodule:: pst.view.PstPlotter

.. autoclass:: PstPlotter
   :members:
