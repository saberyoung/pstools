.. pst.view:

.. currentmodule:: pst.view


:mod:`view`
=========================

make figure
--------------------
.. autosummary::
   :toctree: generated/

   PstPlotter
