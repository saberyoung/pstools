pstools tutorial
===================================

See the Jupyter Notebook version of this tutorial at
https://github.com/saberyoung/pstools/tree/master/notebook

