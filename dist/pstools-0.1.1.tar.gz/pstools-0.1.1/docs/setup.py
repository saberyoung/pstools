import os
os.system('git add .')
os.system('git commit -m "update"')
os.system('git push')
