# PSTools: Pointing Scheduler in responce to Triggers

**tutorial**

https://pstools-documentation.readthedocs.io/en/latest/

Don't hesitate to contact me (sheng.yang@inaf.it) if you found any problems in using the tool. 

'Anything that can possibly go wrong, will go wrong.'
--MURPHY'S LAW on debugging
